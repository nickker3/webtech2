<?php
// class-autoload.inc.php

// Autoload-functie registreren
spl_autoload_register('myAutoloader');

function myAutoloader($className) {
    // Mappen waar klassen kunnen worden gevonden
    $paths = ['classes/', 'models/', 'controllers/', 'views/'];
    $extension = '.class.php';

    foreach ($paths as $path) {
        $fullPath = $path . $className . $extension;

        if (file_exists($fullPath)) {
            require_once $fullPath;
            return;
        }
    }

    // Als het bestand niet wordt gevonden
    error_log("Autoload error: Could not find class $className in specified paths.");
}
