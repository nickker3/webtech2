<?php
// classes/ShareModel.class.php

class ShareModel extends dbh {
    public function createShare($title, $body, $link, $userId) {
        $sql = "INSERT INTO shares (title, body, link, user_id) VALUES (:title, :body, :link, :user_id)";
        $stmt = $this->connect()->prepare($sql);
        $stmt->bindParam(':title', $title);
        $stmt->bindParam(':body', $body);
        $stmt->bindParam(':link', $link);
        $stmt->bindParam(':user_id', $userId);
        $stmt->execute();
    }
}
