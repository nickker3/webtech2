<!-- login.php -->
<h2>Inloggen</h2>
<form action="../views/process_login.php" method="POST">
    <label>Gebruikersnaam: <input type="text" name="username" required></label><br>
    <label>Wachtwoord: <input type="password" name="password" required></label><br>
    <button type="submit">Inloggen</button>
</form>
<p>Heeft u nog geen account? <a href="../index.php?page=register">Registreer hier</a></p>
